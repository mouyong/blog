<?php
    namespace Org\My;
    class cs{
        public $name = '牟勇';
    }
