$(function(){
	// var obj=null;
	// var As=document.getElementById('topnav').getElementsByTagName('a');
	// obj = As[0];
	// for(i=1;i<As.length;i++){if(window.location.href.indexOf(As[i].href)>=0)
	// obj=As[i];}
	// obj.id='topnav_current'
	//home();
});
/*
function home() {
	var obj = null;
	var As = document.getElementById("header_nav").getElementsByTagName("a");
	obj = As[0];
    var j = As.length;
	for (var i = 1; i < As.length; i++) {
		if (window.location.href.indexOf(As[i].href) >= 0) {
			obj = As[i];
		}
	}
	obj.id = "selected";
}
*/